"use client";

import type { CSSProperties } from "react";
import { formatPoints, type GameType } from "@/lib/skillion";
import { GAME_INFO } from "./game-info";

export function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  );
}

/** Pre-game screen: big lowercase title, a short description, and a rectangular start button. */
export function GameIntro({
  type,
  name,
  maxPoints,
  onStart,
  onClose,
}: {
  type: GameType;
  name: string;
  maxPoints: number;
  onStart: () => void;
  onClose: () => void;
}) {
  const info = GAME_INFO[type];
  const title = name.toUpperCase();
  // Shrink long names so the title always fits on one line.
  const titleSize = Math.min(13, 70 / (title.length * 0.72));
  return (
    <div
      className="stage-intro"
      style={{ "--title-size": `${titleSize}cqw` } as CSSProperties}
    >
      <button type="button" className="stage-close intro" onClick={onClose} aria-label="Close">
        <CloseIcon />
      </button>
      <h2 id="game-title" className="stage-title">{title}</h2>
      <div className="stage-copy">
        <p>{info.how}</p>
      </div>
      <div className="stage-intro-foot">
        <div className="stage-worth">
          <small>Max points</small>
          <b>{formatPoints(maxPoints)}</b>
        </div>
        <button type="button" className="stage-start" onClick={onStart} aria-label={`Start ${name}`} autoFocus>
          <span>PLAY</span>
          <span className="stage-start-arrow" aria-hidden="true">▶</span>
        </button>
      </div>
    </div>
  );
}
